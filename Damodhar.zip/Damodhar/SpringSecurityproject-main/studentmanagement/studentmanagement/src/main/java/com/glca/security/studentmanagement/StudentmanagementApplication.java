package com.glca.security.studentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.glca.security.studentmanagement","com.glca.security.studentmanagement.controller","com.glca.security.studentmanagement.entity","com.glca.security.studentmanagement.repository","com.glca.security.studentmanagement.service","com.glca.security.studentmanagement.security"})
public class StudentmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentmanagementApplication.class, args);
	}

}
