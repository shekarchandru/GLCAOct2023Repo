package com.glca.swag.ayushswagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.glca.swag.ayushswagger.model.GreatLearning;



@SpringBootApplication
public class AyushswaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AyushswaggerApplication.class, args);
		System.out.println("Hello spring boot");
		System.out.println("Hello Dev Tool");
	}
	public void run(String... args) throws Exception
	{
		GreatLearning greateLearning = new GreatLearning();
		greateLearning.setCourseName("Design Microveservice with Spring Boot");
		greateLearning.setCourseType("Information Technology");
		//greateLearning.setInstructorName("Christiano Technology");
		
		System.out.println("Greaate learning "+greateLearning);
	}

}
