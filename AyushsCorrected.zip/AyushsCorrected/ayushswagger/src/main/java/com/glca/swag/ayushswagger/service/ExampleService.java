package com.glca.swag.ayushswagger.service;

import com.glca.swag.ayushswagger.model.GreatLearning;

public interface ExampleService {

	// @ResponseBody
	GreatLearning get();

	GreatLearning custominfo(String courseName, String couresType, String FirstName, String LastName);

}