package com.glca.swag.ayushswagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyushswaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
