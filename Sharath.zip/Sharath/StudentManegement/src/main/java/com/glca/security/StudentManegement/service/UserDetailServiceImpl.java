package com.glca.security.StudentManegement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.glca.security.StudentManegement.entity.User;
import com.glca.security.StudentManegement.repository.UserRepository;
import com.glca.security.StudentManegement.security.MyUserDetails;

public class UserDetailServiceImpl implements UserDetailsService  {
	@Autowired
private UserRepository userRepository;



@Override
public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	// TODO Auto-generated method stub
	
	User user=userRepository.getUserByUserName(username);
	System.out.println("User is "+user);
	if(user==null) {
		throw new UsernameNotFoundException("Could not found user");
	}
	return new MyUserDetails(user);

}
}
