package com.glca.security.StudentManegement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.glca.security.StudentManegement.entity","com.glca.security.StudentManegement.controller","com.glca.security.StudentManegement.repository","com.glca.security.StudentManegement.service","com.glca.security.StudentManegement.security"})
public class StudentManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementApplication.class, args);
		System.out.println("spring boot");
	}

}
