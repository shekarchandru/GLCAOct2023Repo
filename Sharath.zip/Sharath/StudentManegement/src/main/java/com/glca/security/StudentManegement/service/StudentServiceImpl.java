package com.glca.security.StudentManegement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.glca.security.StudentManegement.entity.Student;
import com.glca.security.StudentManegement.repository.StudentRepository;
@Repository
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	StudentRepository studentRepository;
	@Transactional
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		List<Student> students=studentRepository.findAll();
		return students;
	}

	@Transactional
	public Student findeById(int id) {
		// TODO Auto-generated method stub
		Student student=new Student();
		student=studentRepository.findById(id).get();
		return student;
	}

	@Transactional
	public void save(Student thestudent) {
		// TODO Auto-generated method stub
		studentRepository.save(thestudent);
	}

	@Transactional
	public void delteById(int theId) {
		// TODO Auto-generated method stub
		studentRepository.deleteById(theId);
	
		
	}

}
