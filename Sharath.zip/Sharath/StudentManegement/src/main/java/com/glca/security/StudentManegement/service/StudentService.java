package com.glca.security.StudentManegement.service;

import java.util.List;


import com.glca.security.StudentManegement.entity.Student;

public interface StudentService {
	public List<Student> findAll();
	public Student findeById(int id);
	public void save(Student thestudent);
	public void delteById(int theId);

}
