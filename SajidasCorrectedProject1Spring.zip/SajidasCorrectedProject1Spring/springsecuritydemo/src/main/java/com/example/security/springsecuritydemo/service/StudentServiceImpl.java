package com.example.security.springsecuritydemo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.security.springsecuritydemo.entity.Student;
import com.example.security.springsecuritydemo.repository.StudentRepository;

@Repository
public class StudentServiceImpl implements StdentService {
	
	@Autowired
	StudentRepository studentRepository;
	
	@Transactional
	public List<Student> findAll() {
		List<Student> students=studentRepository.findAll();
		return students;
	}

	@Transactional
	public Student findById(int theId) {
		Student student=new Student();
		student=studentRepository.findById(theId).get();
		return student;
	}

	@Transactional
	public void save(Student theStudent) {
		
		studentRepository.save(theStudent);
	}

	@Transactional
	public void deleteById(int theId) {
		studentRepository.deleteById(theId);
	}

}
