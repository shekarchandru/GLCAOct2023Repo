package com.example.security.springsecuritydemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.security.springsecuritydemo.entity.Student;
public interface StdentService {

	public List<Student> findAll();
	public Student findById(int theId);
	public void save(Student theStudent);
	public void deleteById(int theId);
}
