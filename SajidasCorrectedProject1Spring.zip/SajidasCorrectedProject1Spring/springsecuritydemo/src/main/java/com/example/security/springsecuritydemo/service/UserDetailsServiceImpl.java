package com.example.security.springsecuritydemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.security.springsecuritydemo.entity.User;
import com.example.security.springsecuritydemo.repository.UserRepository;
import com.example.security.springsecuritydemo.security.MyUserDetails;

public class UserDetailsServiceImpl implements  org.springframework.security.core.userdetails.UserDetailsService{

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user=userRepository.getUserByUserName(username);
		if(user==null)
			throw new UsernameNotFoundException("could not find user");
		return new MyUserDetails(user);
	}
	
	
}
