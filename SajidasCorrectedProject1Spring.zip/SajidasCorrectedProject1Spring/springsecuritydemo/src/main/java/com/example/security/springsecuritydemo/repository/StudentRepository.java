package com.example.security.springsecuritydemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.security.springsecuritydemo.entity.Student;

public interface StudentRepository extends JpaRepository<Student,Integer> {

}
