package com.glca.swag.arjunsswagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArjunsswaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
