package com.glca.swag.arjunsswagger.service;

import com.glca.swag.arjunsswagger.model.GreatLearning;

public interface ExampleService {

	// @ResponseBody
	GreatLearning get();

	GreatLearning custominfo(String courseName, String couresType, String FirstName, String LastName);

}