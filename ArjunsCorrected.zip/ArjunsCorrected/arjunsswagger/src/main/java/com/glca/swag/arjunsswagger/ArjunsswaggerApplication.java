package com.glca.swag.arjunsswagger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.glca.swag.arjunsswagger.model.GreatLearning;
import com.glca.swag.arjunsswagger.serviceImpl.ExampleServiceImpl;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class ArjunsswaggerApplication {

	@Autowired
	ExampleServiceImpl libraryReadServiceImpl;
	
	public static void main(String[] args) {
		SpringApplication.run(ArjunsswaggerApplication.class, args);
		System.out.println("Spring boot library");
		System.out.println("Hello Dev-Tools");
	}
	
	public void run(String... args) throws Exception{
		GreatLearning greatLearning=new GreatLearning();
		greatLearning.setCourseName("Designing microservices with spring boot");///these setCourseName AND setcourseType ARE are auto genereted
		greatLearning.setCourseType("Information Technology");
	
		System.out.println("great learning "+greatLearning);
		
	}

}
