package com.gl.rest.employeerestproj1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Employeerestproj1Application {

	public static void main(String[] args) {
		SpringApplication.run(Employeerestproj1Application.class, args);
	}

}
