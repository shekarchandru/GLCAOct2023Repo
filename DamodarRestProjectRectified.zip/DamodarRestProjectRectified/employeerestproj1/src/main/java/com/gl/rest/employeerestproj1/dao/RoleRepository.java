package com.gl.rest.employeerestproj1.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.rest.employeerestproj1.entity.Role;



public interface RoleRepository extends JpaRepository<Role, Integer> {

}
