package com.springBootActuators;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMavenActuatorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
