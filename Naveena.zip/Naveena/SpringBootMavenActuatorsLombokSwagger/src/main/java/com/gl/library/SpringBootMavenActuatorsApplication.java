package com.gl.library;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gl.library.model.GreatLearning;

@SpringBootApplication(scanBasePackages={"com.gl.library"})
public class SpringBootMavenActuatorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMavenActuatorsApplication.class, args);
		System.out.println("Actuators Swagger Lombok");	
	}
	

	public void run(String...args) throws Exception{
		GreatLearning greatLearning=new GreatLearning();
		greatLearning.setCourseName("Design Microservices with spring Boot");
		greatLearning.setCourseType("Information Technology");
		//greatLearning.setInstructorName("Chandra sir");
		
		System.out.println("Great Learning "+greatLearning);
	}

}
