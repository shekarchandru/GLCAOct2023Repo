package com.gl.library.serviceImpl;

import org.springframework.stereotype.Service;

import com.gl.library.model.FullName;
import com.gl.library.model.GreatLearning;
import com.gl.library.service.ExampleService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExampleServiceImpl implements ExampleService{

	@Override
	public GreatLearning get() {
		// TODO Auto-generated method stub
		log.info("Inside get() Method");
		GreatLearning greatLearning=new GreatLearning();
		greatLearning.setCourseName("Learn Controllers inspring Boot");
		greatLearning.setCourseType("Information Technology");
		greatLearning.setInstructorName(FullName.builder().firstName("Chandra").lastName("Sir").build());
		return greatLearning;
	}

	@Override
	public GreatLearning custominfo(String courseName, String courseType, String firstName,String lastName) {
		// TODO Auto-generated method stub
		log.info("Inside get() Method");
		GreatLearning greatLearning=new GreatLearning();
		greatLearning.setCourseName(courseName);
		greatLearning.setCourseType(courseType);
		greatLearning.setInstructorName(FullName.builder().firstName(firstName).lastName(lastName).build());
		return greatLearning;
	}

}
