package com.gl.library.model;

import lombok.Data;

/*   Below are lombok annotations 
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Setter
@Getter */
//Below @Data annotation will generates all things(shortcut)
@Data
public class GreatLearning {
	
	private String courseName;
	private String courseType;
	private FullName instructorName;

}
