package com.gl.library.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
public class Library {
	
	@Id
	private long id;
	private String name;
	private String commaSeperatedBooknames;
}
