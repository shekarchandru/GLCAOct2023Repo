package com.example.rest.springrestemployee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.rest.springrestemployee.dao.EmployeeRepository;
import com.example.rest.springrestemployee.dao.RoleRepository;
import com.example.rest.springrestemployee.dao.UserRepository;
import com.example.rest.springrestemployee.entity.Employee;
import com.example.rest.springrestemployee.entity.Role;
import com.example.rest.springrestemployee.entity.User;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	private EmployeeRepository employeeRepository;
	
	@Autowired
	RoleRepository roleRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	BCryptPasswordEncoder bcryptEncoder;
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		this.employeeRepository=employeeRepository;
	}
	
	@Override
	public List<Employee> findAll() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee findById(int id) {
		Optional<Employee> result= employeeRepository.findById(id);
		Employee employee=null;
		if(result.isPresent()) {
			employee=result.get();
		}
		else {
			throw new RuntimeException("Did not find employee id -"+ id);
		}
		return employee;
	}

	@Override
	public void save(Employee employee) {
		employeeRepository.save(employee);
		
	}

	@Override
	public void deleteById(int id) {
		employeeRepository.deleteById(id);
		
	}

	@Override
	public List<Employee> searchByFirstName(String firstName) {
		
	//	return employeeRepository.findByFirstNameContainsAllIgnoredCase(firstName);
		return employeeRepository.findByFirstNameContainsAllIgnoreCase(firstName);
	}

	@Override
	public List<Employee> sortByFirstNameAsc() {
		
		return employeeRepository.findAllByOrderByFirstNameAsc();
	}

	@Override
	public User saveUser(User user) {
		user.setPassword(bcryptEncoder.encode(user.getPassword()));
		return userRepository.save(user);
	}

	@Override
	public Role saveRole(Role role) {
		
		return roleRepository.save(role);
	}

}
