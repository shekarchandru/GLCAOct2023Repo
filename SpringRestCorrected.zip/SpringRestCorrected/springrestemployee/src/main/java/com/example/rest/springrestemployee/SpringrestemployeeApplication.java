package com.example.rest.springrestemployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestemployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestemployeeApplication.class, args);
	}

}
