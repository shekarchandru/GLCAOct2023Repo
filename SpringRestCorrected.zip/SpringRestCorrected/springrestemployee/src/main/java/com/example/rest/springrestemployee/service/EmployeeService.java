package com.example.rest.springrestemployee.service;

import java.util.List;

import com.example.rest.springrestemployee.entity.Employee;
import com.example.rest.springrestemployee.entity.Role;
import com.example.rest.springrestemployee.entity.User;

public interface EmployeeService {

	public List<Employee> findAll();
	public Employee findById(int id);
	public void save(Employee employee);
	public void deleteById(int id);
	public List<Employee> searchByFirstName(String firstName);
	public List<Employee> sortByFirstNameAsc();
	public User saveUser(User user);
	public Role saveRole(Role role);
}
