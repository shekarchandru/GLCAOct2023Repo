package com.example.rest.springrestemployee.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.rest.springrestemployee.entity.Role;


public interface RoleRepository extends JpaRepository<Role,Integer>{

}
