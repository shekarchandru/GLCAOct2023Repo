package com.example.rest.springrestemployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrestemployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
