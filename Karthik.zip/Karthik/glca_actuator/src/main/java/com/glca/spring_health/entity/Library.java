package com.glca.spring_health.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
@Entity
public class Library {

	@Id
	int id;
	String name;
	String commaseperatedBooknames;
}
