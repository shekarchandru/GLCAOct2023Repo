package com.glca.spring_health;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.glca.spring_health.model.FullName;
import com.glca.spring_health.model.GreatLearning;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication(scanBasePackages = { "com.glca.spring_health.controller","com.glca.spring_health.service" })
@EnableSwagger2
public class GlcaActuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlcaActuatorApplication.class, args);
		System.out.println("Hello World");
		
	}
	
//		@Override
		public void run(String... args) throws Exception
		{
			GreatLearning g =new GreatLearning();
			g.setCourseName("actuator example");
			g.setCourseType("Great Learning");
			g.setInstructurName(FullName.builder().FirstName("K Akhil").LastName("Sai").build());
					
			System.out.println("Great Learning "+g);
		}
		
	

}
