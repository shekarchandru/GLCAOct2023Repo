package com.glca.spring_health.service;

import com.glca.spring_health.model.GreatLearning;

public interface ExampleService {

	GreatLearning get();
	GreatLearning custominfo(String cName,String cType,String fName,String lName);
}
