package com.glca.spring_health.repository;

import com.glca.spring_health.entity.Library;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibraryRepository extends JpaRepository<Library,Long>{

}
